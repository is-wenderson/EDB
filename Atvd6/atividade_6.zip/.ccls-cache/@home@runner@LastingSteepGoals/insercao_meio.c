#include <stdio.h>
#include "insercao_meio.h"

void insercao_no_meio_da_lsl();