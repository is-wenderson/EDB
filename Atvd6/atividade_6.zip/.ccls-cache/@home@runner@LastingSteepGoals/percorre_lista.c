#include <stdio.h>
#include "percorre_lista.h"

void percorre_a_lsl();