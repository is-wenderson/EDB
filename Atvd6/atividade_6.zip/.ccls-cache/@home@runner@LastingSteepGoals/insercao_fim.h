#ifndef INSERCAO_FIM_H
#define INSERCAO_FIM_H
#include "no.h"
#include <stdio.h>
#include <stdlib.h>
  void insercao_no_fim_da_lsl(No **cabeca, int valor){
    No *novo_no = (No *) malloc(sizeof(No)); //cria um novo espaço na memória para o novo nó.
    novo_no->valor = valor; //cria um novo nó A.
    novo_no->proximo = NULL;
    //diz que o promximo aponta para null, ou seja, ultimo elemento da lista
    if(*cabeca == NULL){
      //verifica se a lista está vazia
      *cabeca = novo_no;
      return;
    }

    No *atual = *cabeca;
    //o no atual recebe o endereço do primeiro elemento da lista
    while(atual->proximo != NULL) {
    //enquanto o proximo elemento não for null, ou seja, o ultimo elemento da lista, o atual recebe o endereço do proximo elemento da lista
      atual = atual->proximo;
    }
    //por fim, o valor atual se torna o ultimo elemento da lista
    atual->proximo = novo_no;
  }

#endif