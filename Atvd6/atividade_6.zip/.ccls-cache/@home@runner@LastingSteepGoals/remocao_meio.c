#include <stdio.h>
#include "remocao_meio.h"

void remocao_no_meio_da_lsl();