#ifndef INSERCAO_INICIO_H
#define INSERCAO_INICIO_H
#include "no.h"
#include <stdio.h>
#include <stdlib.h>

void insercao_no_inicio_da_lsl(No **cabeca, int valor) {
  No *novo_no = (No *) malloc(sizeof(No)); // cria um novo espaço na memória para o novo nó.
  novo_no->valor = valor; // cria um novo nó A.
  novo_no->proximo = *cabeca; // o novo nó A aponta para o nó B.
  *cabeca = novo_no; // o nó B passa a ser o nó A e o antigo nó A passa a ser null, assim é realizada a inserção no inicio da lista.
}

#endif