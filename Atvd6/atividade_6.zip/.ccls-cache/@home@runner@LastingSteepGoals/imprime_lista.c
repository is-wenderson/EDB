#include <stdio.h>
#include "imprime_lista.h"

void imprime_a_lsl();