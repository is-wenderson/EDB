#include <stdio.h>
#include "insercao_fim.h"

void insercao_no_fim_da_lsl();