#ifndef IMPRIME_LISTA_H
#define IMPRIME_LISTA_H
#include "no.h"
#include <stdio.h>
#include <stdlib.h>
  void imprime_a_lsl(No *cabeca) {
    if(cabeca == NULL){
      printf("Lista vazia!\n");
      return;
    }

    No *atual = cabeca;

    while(atual != NULL){
      printf("%d ", atual->valor);
      atual = atual->proximo;
    }
    printf("\n");
  }

#endif