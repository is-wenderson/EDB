#include <stdio.h>
#include "busca_valor.h"

void busca_por_valor_na_lsl();