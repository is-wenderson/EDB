#include "no.h"
#ifndef INSERCAO_MEIO_H
#define INSERCAO_MEIO_H
#include "insercao_inicio.h"
#include <stdio.h>
#include <stdlib.h>
void insercao_no_meio_da_lsl(No **cabeca, int valor, int posicao){
  if(posicao == 0){
insercao_no_inicio_da_lsl(cabeca, valor);
    //condicional para verificar se o valor a ser inserido é o primeiro da lista, caso seja chama-se a função inserção no início da lista.
    return;
  }

  No *anterior = NULL;
  No *atual = *cabeca;
  int i = 0;

  while(atual != NULL && i < posicao){
    //funciona para verificar se o valor não é o ultimo da lista e se é maior que o primeiro elemento da lista
    anterior = atual;
    atual = atual->proximo;
    i++;
    //caso seja maior que o primeiro elemento da lista, o anterior recebe o atual e o atual recebe o próximo elemento da lista.
  }

  if(atual == NULL) {
    printf("Posição inválida!\n");
    return;
  }
  //verifica se o no atual é o ultimo

  
  No *novo_no = (No *)malloc(sizeof(No));
  //cria um novo novo nó
  novo_no->valor = valor;
  novo_no->proximo = atual;
  //o novo nó recebe o valor e o próximo recebe o atual, que sabemos que é um valor diferente do ultimo da lista
  if(anterior != NULL){
    anterior->proximo = novo_no;
    //verifica se o anterior é diferente de null, caso seja, o anterior recebe o novo nó
  }else{
    //caso não seja, o novo nó recebe o valor e o proximo receb o atual, que é o primeiro elemento da lista
    *cabeca = novo_no;
  }
}


#endif