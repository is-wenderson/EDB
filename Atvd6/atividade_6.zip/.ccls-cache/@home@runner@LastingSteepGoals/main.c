#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "no.h"
#include "busca_valor.h" 
#include "imprime_lista.h" 
#include "insercao_fim.h" 
#include "insercao_inicio.h" 
#include "insercao_meio.h" 
#include "percorre_lista.h" 
#include "remocao_fim.h"
#include "remocao_inicio.h"
#include "remocao_meio.h"

int main(){
   No *cabeca = NULL; 


  // Insere elementos no início da lista.
  insercao_no_inicio_da_lsl(&cabeca, 10);

 
  // Insere elementos no fim da lista.
  insercao_no_fim_da_lsl(&cabeca, 40);

 
  // Insere elemento em uma posição intermediária da lista.
  insercao_no_meio_da_lsl(&cabeca, 25, 3);


  // Remove no início da lista.
  remocao_no_inicio_da_lsl(&cabeca);


  // Remove no fim da lista.
  remocao_no_fim_da_lsl(&cabeca); // Correct callcabeca);

  // Remove em uma posição intermediária na lista por valor.
  remocao_no_meio_da_lsl(&cabeca, 20);

  
  // Busca por um valor na lista.
  busca_por_valor_na_lsl(cabeca, 70);

  // Varre a lista.
  percorre_a_lsl(cabeca);
}