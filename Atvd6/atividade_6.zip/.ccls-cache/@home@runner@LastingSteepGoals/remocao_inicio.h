#ifndef REMOCAO_INICIO_H
#define REMOCAO_INICIO_H
#include "no.h"
#include <stdio.h>
#include <stdlib.h>
void remocao_no_inicio_da_lsl(No **cabeca){
    if(*cabeca == NULL){
      printf("A lista está vazia!\n");
      return;
    }
    //inicialmente verifica se a lista está vazia, caso não esteja, o nó atual recebe o nó que está apontando para o próximo e o anterior, ou seja, o nó temporario é liberado da memória com o free.

    No *temp = *cabeca;
    *cabeca = (*cabeca)->proximo;
    free(temp);
  }


#endif