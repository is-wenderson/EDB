#include <stdio.h>
#include "insercao_inicio.h"

void insercao_no_inicio_da_lsl();