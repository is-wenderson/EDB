#ifndef "INSERCAO_FIM_H"
#define "INSERCAO_FIM_H"

  void insercao_no_fim_da_lsl(No **cabeca, int valor){
    No *novo_no = malloc(sizeof(No)); //cria um novo espaço na memória para o novo nó.
    novo_no->valor = valor; //cria um novo nó A.
    novo_no->proximo = NULL;

    if(*cabeca == NULL){
      *cabeca = novo_no;
      return;
    }

    No *atual = *cabeca;

    while(atual->proximo != NULL) {
      atual = atual->proximo;
    }

    atual->proximo = novo_no;
  }

#endif