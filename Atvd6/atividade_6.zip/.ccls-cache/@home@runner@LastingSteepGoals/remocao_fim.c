#include <stdio.h>
#include "remocao_fim.h"

void remocao_no_fim_da_lsl();