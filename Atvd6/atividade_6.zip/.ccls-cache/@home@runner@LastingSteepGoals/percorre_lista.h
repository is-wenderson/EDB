#ifndef PERCORRE_LISTA_H
#define PERCORRE_LISTA_H
#include "no.h"
#include <stdio.h>
#include <stdlib.h>
  void percorre_a_lsl(No *cabeca){
    No *atual = cabeca;
    int total = 0;
    //codigo para percorrer toda a lista e imprimir o total de elementos
    while(atual != NULL){
      total = total + atual->valor;
      atual = atual->proximo;
    }
    printf("Total = %d.\n", total);
  }

#endif