#ifndef NO_H
#define NO_H
struct no{
  int valor;
  struct no *proximo;
};

// Definição do tipo 'No'.
typedef struct no No;

#endif