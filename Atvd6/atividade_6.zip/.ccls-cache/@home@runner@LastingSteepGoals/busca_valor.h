#ifndef BUSCA_VALOR_H
#define BUSCA_VALOR_H
#include "no.h"
#include <stdio.h>
#include <stdlib.h>
  void busca_por_valor_na_lsl(No *cabeca, int valor){
    No *atual = cabeca;
    //faz uma varredura na lista até encontrar o valor desejado.
    while(atual != NULL && atual->valor != valor){
      atual = atual->proximo;
    }

    if(atual != NULL)
      printf("Valor %d encontrado!\n", valor);
    else
     printf("Valor %d não encontrado!\n", valor);
  }

#endif