#ifndef REMOCAO_MEIO_H
#define REMOCAO_MEIO_H
#include "no.h"
#include <stdio.h>
#include <stdlib.h>
  void remocao_no_meio_da_lsl(No **cabeca, int valor){
    if(*cabeca == NULL){
      printf("Lista vazia!\n");
      return;
    }

    No *anterior = NULL;
    No *atual = *cabeca;

    //percorre a lista até encontrar o valor a ser removido, ou seja, supondo que não seja o ultimo elemento
    while(atual != NULL && atual->valor != valor){
      anterior = atual;
      atual = atual->proximo;
    }

    if(atual == NULL){
      printf("Valor inexistente na lista!\n");
      return;
    }
    //verifica se o valor a ser removido é o primeiro elemento da lista iy i 
    if(anterior == NULL){
      *cabeca = atual->proximo;
    }else{
      anterior->proximo = atual->proximo;
    }
    //se o nó a ser removido está no meio ou no final da lista, o ponteiro proximo do nó anterior é atualizado para pular o nó atual.

    //memoria liberada
  
    free(atual);
  }


#endif