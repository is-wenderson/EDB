#include <stdio.h>
#include "remocao_inicio.h"

void remocao_no_inicio_da_lsl();