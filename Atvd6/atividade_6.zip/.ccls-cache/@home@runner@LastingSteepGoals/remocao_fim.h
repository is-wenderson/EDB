#ifndef REMOCAO_FIM_H
#define REMOCAO_FIM_H
#include "no.h"
#include "remocao_inicio.h"
#include <stdio.h>
#include <stdlib.h>
  void remocao_no_fim_da_lsl(No **cabeca){
    if(*cabeca == NULL || (*cabeca)->proximo == NULL){
      remocao_no_inicio_da_lsl(cabeca);
      return;
      //verifica o primeiro nó está vazio ou se o próximo valor está vazio, caso esteja é chamada a função para remover no inicio
    }

    No *anterior = NULL;
    No *atual = *cabeca;
    //nesta etapa defico que meu valor anterior vai ser igual a null e o atual vai ser igual a cabeca, que é o primeiro nó da lista
    while(atual->proximo != NULL){
      anterior = atual;
      atual = atual->proximo;
      //enquanto o atual for diferente de null, o anterior vai ser igual ao atual
    }

    anterior->proximo = NULL;
    //com isso, quando o anterior, que é o penúltimo nó, for diferente de null, ele será igual a null, assim o último no será removido utilizando o free
    free(atual);
  }



#endif